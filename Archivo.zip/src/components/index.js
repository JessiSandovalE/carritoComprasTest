import React from 'react'
import Router from './router'
//components
import Navbar from './navbar'


const Aplication = () => {
  return (
    <div>
      <Navbar/>
      <Router/>
    </div>
  )
}

export default Aplication
